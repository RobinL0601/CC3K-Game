#include "human.h"

Human::Human(): Player(140,140,20,20,0,'@', "Human"){}
