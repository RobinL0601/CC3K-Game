#include "elves.h"

Elves::Elves(): Player{140,140,30,10,0,'@', "Elf"} {}
