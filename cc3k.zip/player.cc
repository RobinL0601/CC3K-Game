#include "player.h"

Player::Player(int max_health, int def, int atk, int hp, int gold, char theChar, std::string race): 
        Creature{max_health, def, atk, hp, gold, theChar, race} {}

