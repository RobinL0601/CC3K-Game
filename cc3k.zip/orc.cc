#include "orc.h"

Orc::Orc(): Player(180,180,30,25,0,'@', "Orc"){}
