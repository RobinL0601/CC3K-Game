#ifndef ORC_H
#define ORC_H

#include "player.h"

class Orc: public Player {
public:
    Orc();
};

#endif
