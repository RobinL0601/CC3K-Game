#ifndef ELVES_H
#define ELVES_H

#include "player.h"

class Elves: public Player {
public:
    Elves();
};

#endif
