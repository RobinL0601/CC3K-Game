#include "dwarf.h"

Dwarf::Dwarf(): Player{100,100,20,30,0,'@', "Dwarf"} {}
